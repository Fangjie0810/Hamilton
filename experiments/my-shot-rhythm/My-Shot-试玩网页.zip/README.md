# MY SHOT · 单页音游试玩

本包包含已经构建好的网页与原歌曲，在本机启动即可试玩。
解压后，在此目录运行：

    python3 -m http.server 1787 --bind 127.0.0.1 --directory site

打开 http://127.0.0.1:1787/ （需要 HTTP 服务，请勿直接双击 HTML）。

D / F / J / K 敲击；空格暂停/继续；Esc 暂停；R 重新开始。
提供下落式/圆点式、入门/标准、完整歌曲/45秒/分段练习、自动演示、输入校准。
完整录音5分33秒；入门341音符，标准639音符。这是信号分析辅助的实验谱，尚未逐句人工听审。

源码与可复现谱面生成脚本保存在原 Hamilton 工作区的 experiments/my-shot-rhythm/。
详细分析见本包 music-analysis.md，谱面数据见 chart.json。

English: Run the command above and open the local URL. Play with D/F/J/K; Space pauses, Esc pauses, R restarts. This is a signal-guided experimental arrangement, pending phrase-by-phrase human musical review.
